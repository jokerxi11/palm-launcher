// SPDX-License-Identifier: MIT
pragma solidity 0.8.20;

import {Script, console} from "forge-std/Script.sol";
import {PalmLauncher} from "../src/PalmLauncher.sol";

/// @notice Deploys the generic launcher contract. This is a ONE-TIME deployment per chain --
///         the same launcher instance is reused to launch any number of different tokens.
///         It does not count against the "two transactions per launch" budget once deployed.
/// @dev Run with:
///      forge script script/DeployLauncher.s.sol:DeployLauncher --rpc-url $RPC_URL --broadcast
contract DeployLauncher is Script {
    function run() external returns (PalmLauncher launcher) {
        uint256 deployerKey = vm.envUint("PRIVATE_KEY");
        address router = vm.envAddress("ROUTER");

        vm.startBroadcast(deployerKey);
        launcher = new PalmLauncher(router);
        vm.stopBroadcast();

        console.log("================ LAUNCHER DEPLOYED ================");
        console.log("Launcher Address:", address(launcher));
        console.log("Router:          ", router);
        console.log("Factory:         ", address(launcher.factory()));
        console.log("=====================================================");
        console.log("Next: set LAUNCHER_ADDRESS in .env, then run Launch.s.sol to launch any token");
    }
}
