// SPDX-License-Identifier: MIT
pragma solidity 0.8.20;

import {Script, console} from "forge-std/Script.sol";
import {Token} from "../src/Token.sol";

/// @notice TRANSACTION 1: deploys the standard, fixed-supply ERC20 token.
/// @dev Run with:
///      forge script script/DeployToken.s.sol:DeployToken --rpc-url $RPC_URL --broadcast
contract DeployToken is Script {
    function run() external returns (Token token) {
        uint256 deployerKey = vm.envUint("PRIVATE_KEY");
        address owner = vm.envAddress("TOKEN_OWNER");
        string memory name_ = vm.envString("TOKEN_NAME");
        string memory symbol_ = vm.envString("TOKEN_SYMBOL");
        uint256 supply = vm.envUint("TOKEN_SUPPLY");

        vm.startBroadcast(deployerKey);
        token = new Token(name_, symbol_, supply, owner);
        vm.stopBroadcast();

        console.log("================ TOKEN DEPLOYED ================");
        console.log("Token Address:", address(token));
        console.log("Name:         ", name_);
        console.log("Symbol:       ", symbol_);
        console.log("Owner:        ", owner);
        console.log("Total Supply: ", supply);
        console.log("==================================================");
        console.log("Next: set TOKEN_ADDRESS in .env to the address above, then deploy the launcher (once per chain) and run Launch.s.sol");
    }
}
