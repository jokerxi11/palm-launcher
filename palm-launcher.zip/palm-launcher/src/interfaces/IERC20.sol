// SPDX-License-Identifier: MIT
pragma solidity 0.8.20;

// Re-exports OpenZeppelin's IERC20 so scripts/tests within this project can import a single,
// local, project-relative path instead of reaching into the OpenZeppelin package directly.
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
