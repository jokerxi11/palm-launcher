// SPDX-License-Identifier: MIT
pragma solidity 0.8.20;

/// @title IUniswapV2Factory
/// @notice Minimal interface for the Uniswap V2 Factory (and compatible forks, e.g. on Robinhood
///         Chain or any other EVM chain running a standard Uniswap V2 deployment).
interface IUniswapV2Factory {
    /// @notice Emitted by the factory when a new pair is created.
    event PairCreated(address indexed token0, address indexed token1, address pair, uint256);

    /// @notice Returns the pair address for `tokenA`/`tokenB`, or the zero address if none exists.
    function getPair(address tokenA, address tokenB) external view returns (address pair);

    /// @notice Creates the pair for `tokenA`/`tokenB` if it does not already exist.
    function createPair(address tokenA, address tokenB) external returns (address pair);
}
