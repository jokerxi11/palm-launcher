// SPDX-License-Identifier: MIT
pragma solidity 0.8.20;

/// @title IUniswapV2Router02
/// @notice Minimal interface exposing only the Uniswap V2 Router02 functions used by this
///         project (and compatible forks on any EVM chain, including Robinhood Chain).
interface IUniswapV2Router02 {
    /// @notice The Factory this router is bound to.
    function factory() external pure returns (address);

    /// @notice The canonical WETH address this router is bound to.
    function WETH() external pure returns (address);

    /// @notice Adds liquidity to a Token/ETH pool, creating the pair first if it does not exist.
    ///         Wraps the attached ETH into WETH internally.
    /// @param token The ERC20 token to pair with ETH.
    /// @param amountTokenDesired The amount of token the caller wants to add.
    /// @param amountTokenMin The minimum acceptable amount of token to add (slippage protection).
    /// @param amountETHMin The minimum acceptable amount of ETH to add (slippage protection).
    /// @param to The recipient of the minted LP tokens.
    /// @param deadline Unix timestamp after which the transaction reverts.
    /// @return amountToken The actual amount of token added.
    /// @return amountETH The actual amount of ETH added.
    /// @return liquidity The amount of LP tokens minted to `to`.
    function addLiquidityETH(
        address token,
        uint256 amountTokenDesired,
        uint256 amountTokenMin,
        uint256 amountETHMin,
        address to,
        uint256 deadline
    )
        external
        payable
        returns (uint256 amountToken, uint256 amountETH, uint256 liquidity);
}
