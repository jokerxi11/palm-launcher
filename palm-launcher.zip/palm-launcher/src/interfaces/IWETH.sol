// SPDX-License-Identifier: MIT
pragma solidity 0.8.20;

/// @title IWETH
/// @notice Minimal interface for wrapped-ETH tokens (WETH9 and compatible forks).
interface IWETH {
    /// @notice Wraps the attached ETH into WETH, crediting msg.sender.
    function deposit() external payable;

    /// @notice Unwraps `amount` of WETH back into ETH, sent to msg.sender.
    function withdraw(uint256 amount) external;

    /// @notice Standard ERC20 approve.
    function approve(address spender, uint256 amount) external returns (bool);

    /// @notice Standard ERC20 transfer.
    function transfer(address to, uint256 amount) external returns (bool);

    /// @notice Standard ERC20 balanceOf.
    function balanceOf(address account) external view returns (uint256);
}
