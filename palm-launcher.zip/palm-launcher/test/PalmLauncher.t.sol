// SPDX-License-Identifier: MIT
pragma solidity 0.8.20;

import {Test, console} from "forge-std/Test.sol";
import {Token} from "../src/Token.sol";
import {PalmLauncher} from "../src/PalmLauncher.sol";
import {IUniswapV2Router02} from "../src/interfaces/IUniswapV2Router02.sol";
import {IUniswapV2Factory} from "../src/interfaces/IUniswapV2Factory.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/// @notice These tests run against a real Uniswap V2 Router/Factory/WETH deployment via a mainnet
///         fork. Set MAINNET_RPC_URL in your environment before running:
///           forge test --match-contract PalmLauncherTest --fork-url $MAINNET_RPC_URL -vvv
contract PalmLauncherTest is Test {
    // Mainnet canonical Uniswap V2 addresses.
    address constant ROUTER = 0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D;
    address constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;

    Token token;
    PalmLauncher launcher;
    address owner = makeAddr("owner");
    address recipient = makeAddr("recipient");

    function setUp() public {
        // Requires --fork-url pointing at an Ethereum mainnet RPC.
        token = new Token("Palm", "PALM", 1_000_000_000 ether, owner);
        launcher = new PalmLauncher(ROUTER);
        vm.deal(owner, 10 ether);
    }

    function test_LaunchCreatesLiquidityAndSendsLpToRecipient() public {
        uint256 tokenAmount = 500_000_000 ether;
        uint256 ethAmount = 1 ether;

        vm.startPrank(owner);
        token.approve(address(launcher), tokenAmount);
        launcher.launch{value: ethAmount}(address(token), tokenAmount, recipient);
        vm.stopPrank();

        address factory = IUniswapV2Router02(ROUTER).factory();
        address pair = IUniswapV2Factory(factory).getPair(address(token), WETH);

        assertTrue(pair != address(0), "pair was not created");
        assertGt(IERC20(pair).balanceOf(recipient), 0, "recipient did not receive LP tokens");
        assertEq(token.balanceOf(address(launcher)), 0, "launcher retained token dust");
        assertEq(address(launcher).balance, 0, "launcher retained ETH dust");
    }

    function test_RevertsOnZeroEth() public {
        vm.startPrank(owner);
        token.approve(address(launcher), 1 ether);
        vm.expectRevert(PalmLauncher.ZeroEth.selector);
        launcher.launch(address(token), 1 ether, recipient);
        vm.stopPrank();
    }

    function test_RevertsOnZeroTokenAmount() public {
        vm.startPrank(owner);
        vm.expectRevert(PalmLauncher.ZeroAmount.selector);
        launcher.launch{value: 1 ether}(address(token), 0, recipient);
        vm.stopPrank();
    }

    function test_RevertsOnZeroRecipient() public {
        vm.startPrank(owner);
        token.approve(address(launcher), 1 ether);
        vm.expectRevert(PalmLauncher.ZeroAddress.selector);
        launcher.launch{value: 1 ether}(address(token), 1 ether, address(0));
        vm.stopPrank();
    }

    function test_OwnerCanRescueForeignToken() public {
        Token foreign = new Token("Foreign", "FRN", 1_000 ether, owner);
        vm.prank(owner);
        foreign.transfer(address(token), 100 ether);

        vm.prank(owner);
        token.rescueERC20(IERC20(address(foreign)), owner, 100 ether);

        assertEq(foreign.balanceOf(owner), 1_000 ether);
    }

    function test_CannotRescueOwnToken() public {
        vm.prank(owner);
        vm.expectRevert(Token.CannotRescueSelf.selector);
        token.rescueERC20(IERC20(address(token)), owner, 1);
    }
}
